package sg.nus.iss.facialrecognition.service;

import sg.nus.iss.facialrecognition.model.QuizQuestionScore;

public interface QuizQuestionScoreService {
    public QuizQuestionScore saveQuizQuestionScore(QuizQuestionScore quizQuestionScore);
}
