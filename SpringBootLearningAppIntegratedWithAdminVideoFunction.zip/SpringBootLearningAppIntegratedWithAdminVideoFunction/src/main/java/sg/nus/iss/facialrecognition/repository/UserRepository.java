package sg.nus.iss.facialrecognition.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import sg.nus.iss.facialrecognition.model.User;


@EnableJpaRepositories
@Repository
public interface UserRepository extends JpaRepository<User, String> {
    User findOneByUserName(String userName);
    User findOneByEmail(String email);
    User findOneByUserNameOrEmail(String username, String email);
    @Modifying
    @Transactional
    @Query("update User u set u.email = :email, u.fullName = :fullName "
            + "where u.userName = :userName")
    int updateUser(
            @Param("userName") String userName,
            @Param("email") String email,
            @Param("fullName") String fullName);
    User findOneByToken(String token);
}
