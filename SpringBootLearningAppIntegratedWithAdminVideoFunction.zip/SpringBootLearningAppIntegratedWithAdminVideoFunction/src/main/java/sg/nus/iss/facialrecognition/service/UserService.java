package sg.nus.iss.facialrecognition.service;

import sg.nus.iss.facialrecognition.model.User;

public interface UserService {
    public User saveUser(User user);

    public User getUserByUserName(String userName);
    Boolean updateUser(User user) ;
    public User register(User user) ;
    public String encodeUserPassword(String password);
    public String createActivationToken(User user, Boolean save);
    public User activate(String activation);
    public String createResetPasswordToken(User user, Boolean save);
    public User resetActivation(String email);
    public Boolean resetPassword(User user);

}
