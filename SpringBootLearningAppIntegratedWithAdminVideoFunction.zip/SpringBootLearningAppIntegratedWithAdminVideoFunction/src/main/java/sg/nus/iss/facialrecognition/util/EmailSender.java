package sg.nus.iss.facialrecognition.util;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

@Component
public class EmailSender{
    @Autowired
    private JavaMailSender emailSender;

    public void sendSimpleMessage(String from, String to, Long feedbackId, String reply) throws Exception {
        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message);

        helper.setFrom(from);
        helper.setTo("yl21770@gmail.com");
        helper.setSubject("FunLearn- Reply to Feedback #" + feedbackId);
        helper.setText(reply);
        emailSender.send(message);
    }
}
