package sg.nus.iss.facialrecognition.service;

import sg.nus.iss.facialrecognition.model.FamilyMember;

public interface FamilyMemberService {
    FamilyMember saveFamilyMember(FamilyMember member);
    
}
