package sg.nus.iss.facialrecognition.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import sg.nus.iss.facialrecognition.model.Role;

@EnableJpaRepositories
@Repository
public interface RoleRepository extends JpaRepository<Role, Integer> {
    
}
