package sg.nus.iss.facialrecognition.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.scrypt.SCryptPasswordEncoder;
import org.springframework.stereotype.Service;


import sg.nus.iss.facialrecognition.model.User;
import sg.nus.iss.facialrecognition.repository.SurveyScoreRepository;
import sg.nus.iss.facialrecognition.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepo;
    @Autowired
    private SurveyScoreRepository surveyScoreRepository;

    @Override
    public User saveUser(User user){
        return userRepo.save(user);
    }

    @Override
    public User getUserByUserName(String userName){
        return userRepo.findOneByUserName(userName);
    }
    @Override
    public Boolean updateUser(User user) {
        String userName = user.getUserName();
        User oldUser = userRepo.findOneByUserName(userName);
        oldUser.setFullName(user.getFullName());
        oldUser.setEmail(user.getEmail());
        userRepo.save(oldUser);
        return true;
    }
    public User register(User user) {
        user.setPassword(encodeUserPassword(user.getPassword()));

        if (userRepo.findOneByUserName(user.getUserName()) == null && userRepo.findOneByEmail(user.getEmail()) == null) {
            String activation = createActivationToken(user, false);
            user.setToken(activation);
            userRepo.save(user);
            return user;
        }

        return null;
    }
    public String encodeUserPassword(String password) {
        BCryptPasswordEncoder passwordEncoder =new BCryptPasswordEncoder();
        return passwordEncoder.encode(password);
    }
    public String createActivationToken(User user, Boolean save) {
        BCryptPasswordEncoder passwordEncoder =new BCryptPasswordEncoder();
        String activationToken = passwordEncoder.encode(user.getUserName());
        if(save) {
            user.setToken(activationToken);
            userRepo.save(user);
        }
        return activationToken;
    }
    public User activate(String activation) {
        if(activation.equals("1") || activation.length()<5) {
            return null;
        }
        User u = userRepo.findOneByToken(activation);
        if(u!=null) {
            u.setToken("1");
            userRepo.save(u);
            return u;
        }
        return null;
    }
    public String createResetPasswordToken(User user, Boolean save) {
        BCryptPasswordEncoder passwordEncoder =new BCryptPasswordEncoder();
        String resetToken = passwordEncoder.encode(user.getEmail());
        if(save) {
            user.setToken(resetToken);
            userRepo.save(user);
        }
        return resetToken;
    }
    public User resetActivation(String email) {
        User u = userRepo.findOneByEmail(email);
        if(u != null) {
            createActivationToken(u, true);
            return u;
        }
        return null;
    }
    public Boolean resetPassword(User user) {
        User u = userRepo.findOneByUserName(user.getUserName());
        if(u != null) {
            u.setPassword(encodeUserPassword(user.getPassword()));
            u.setToken("1");
            userRepo.save(u);
            return true;
        }
        return false;
    }

}
