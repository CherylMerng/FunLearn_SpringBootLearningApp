package sg.nus.iss.facialrecognition.controller;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import sg.nus.iss.facialrecognition.model.User;
import sg.nus.iss.facialrecognition.repository.UserRepository;
import sg.nus.iss.facialrecognition.service.MailService;
import sg.nus.iss.facialrecognition.service.UserService;

import javax.validation.Valid;

@Controller
public class HomeController {
	private Logger log = LoggerFactory.getLogger(HomeController.class);
	@Value("${app.user.verification}")
	private Boolean requireActivation;
	@Autowired
	private UserService userService;
	@Autowired
	private MailService mailService;
	@Autowired
	private UserRepository userRepository;

	@GetMapping({"/","/login"})
    public String login() {
        return "login";
    }
	
    @GetMapping("/accessDenied")
	public String getAccessDeniedPage() {
		return "accessDeniedPage";
	}


	@RequestMapping(value = "/registeraccount", method = RequestMethod.GET)
	public String register(User user) {
		return "/registeraccount";
	}

	@RequestMapping(value = "/registeraccount", method = RequestMethod.POST)
	public String registerPost(@Valid User user, BindingResult result) {
		if (result.hasErrors()) {
			return "/registeraccount";
		}

		User registeredUser = userService.register(user);
		if (registeredUser != null) {
			mailService.sendNewRegistration(user.getEmail(), registeredUser.getToken());

			sendUserDetailEmailPost(user);
			return "register-success";
		} else {
			log.error("User already exists: " + user.getUserName());
			result.rejectValue("email", "error.alreadyExists", "This username or email already exists, please try to reset password instead.");
			return "/registeraccount";
		}
	}
	@RequestMapping(value = "/user/reset-password", method = RequestMethod.GET)
	public String resetPasswordEmail(User user) {
		return "reset-password";
	}

	@RequestMapping(value = "/user/reset-password", method = RequestMethod.POST)
	public String resetPasswordEmailPost(User user, BindingResult result) {
		User u = userRepository.findOneByEmail(user.getEmail());
		if(u == null) {
			result.rejectValue("email", "error.doesntExist", "We could not find this email in our databse");
			return "reset-password";
		} else {
			String resetToken = userService.createResetPasswordToken(u,true);
			mailService.sendResetPassword(user.getEmail(), resetToken);
		}
		return "reset-password-sent";
	}
	public void sendUserDetailEmailPost(User user) {
		// User u = userRepository.findOneByEmail(user.getEmail());
		mailService.sendUserDetails(user.getEmail(), user);
	}
	@RequestMapping(value = "/user/reset-password-change")
	public String resetPasswordChange(User user, BindingResult result, Model model) {
		User u = userRepository.findOneByToken(user.getToken());
		if(user.getToken().equals("1") || u == null) {
			result.rejectValue("activation", "error.doesntExist", "We could not find this reset password request.");
		} else {
			model.addAttribute("userName", u.getUserName());
		}
		return "user/reset-password-change";
	}
	@RequestMapping(value = "/user/reset-password-change", method = RequestMethod.POST)
	public ModelAndView resetPasswordChangePost(User user, BindingResult result) {
		Boolean isChanged = userService.resetPassword(user);
		if(isChanged) {
			return new ModelAndView("redirect:/");
		} else {
			return new ModelAndView("reset-password-change", "error", "Password could not be changed");
		}
	}
	@RequestMapping("/user/activation-send")
	public ModelAndView activationSend(User user) {
		return new ModelAndView("/user/activation-send");
	}

	@RequestMapping(value = "/user/activation-send", method = RequestMethod.POST)
	public ModelAndView activationSendPost(User user, BindingResult result) {
		User u = userService.resetActivation(user.getEmail());
		if(u != null) {
			mailService.sendNewActivationRequest(u.getEmail(), u.getToken());
			return new ModelAndView("activation-sent");
		} else {
			result.rejectValue("email", "error.doesntExist", "We could not find this email in our databse");
			return new ModelAndView("activation-send");
		}
	}
	@RequestMapping("/user/activate")
	public String activate(String activation) {
		User u = userService.activate(activation);
		if(u != null) {
			return "redirect:/";
		}
		return "redirect:/error?message=Could not activate with this activation code, please contact support";
	}

}