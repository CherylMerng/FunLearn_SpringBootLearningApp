package sg.nus.iss.facialrecognition;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.time.LocalDate;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

import sg.nus.iss.facialrecognition.model.*;
import sg.nus.iss.facialrecognition.repository.FeedbackRepository;
import sg.nus.iss.facialrecognition.service.*;

@SpringBootApplication
public class FacialRecognitionPrototypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(FacialRecognitionPrototypeApplication.class, args);

	}

	// method to go through all the files in the folder
	public void saveQuizImages(final File folder, QuizQuestionService quizQuestionService) throws IOException {
		for (final File fileEntry : folder.listFiles()) {
			if (!fileEntry.getName().equals(".DS_Store")) {
				// System.out.println(fileEntry.getName());
				byte[] image = method(fileEntry);
				QuizQuestion question = new QuizQuestion();
				question.setActualEmotion(folder.getName());
				question.setData(image);
				quizQuestionService.saveQuizQuestion(question);
			}
		}
	}

	// To convert file to byte array
	public static byte[] method(File file)
			throws IOException {

		// Creating an object of FileInputStream to
		// read from a file
		FileInputStream fl = new FileInputStream(file);

		// Now creating byte array of same length as file
		byte[] arr = new byte[(int) file.length()];

		// Reading file content to byte array
		// using standard read() method
		fl.read(arr);

		// lastly closing an instance of file input stream
		// to avoid memory leakage
		fl.close();

		// Returning above byte array
		return arr;
	}


@Bean
public RestTemplate getRestTemplate(){
	return new RestTemplate();
}

	@Bean
	public CommandLineRunner commandLineRun(QuizQuestionService quizQuestionService, VideoService videoService,
			UserService userService, RoleService roleService, FamilyMemberService familyMemberService,
			QuizService quizService, SurveyService surveyService, SurveyQuestionService surveyQuestionService,
			FeedbackRepository feedbackRepo, VideoWatchedService videoWatchedService) {
		return args -> {
			// List<File> folders = new ArrayList<File>();
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/angry"));
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/disgust"));
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/fear"));
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/happy"));
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/neutral"));
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/sad"));
			// folders.add(new File("D:/Git
			// Hub/ADProject/FacialRecognitionModelTraining/test/surprise"));
			// for (int i=0; i< folders.size(); i++){
			// System.out.println(folders.get(i).getName());
			// saveQuizImages(folders.get(i), quizQuestionService);
			// }
			Video vid1 = new Video("Telling the time", "Telling the time", "g7mQGSx5lwY",
			"https://img.youtube.com/vi/g7mQGSx5lwY/hqdefault.jpg", LocalDate.of(2022, 12, 20));
			videoService.addVideo(vid1);
			videoService.addVideo(new Video(
					"Street Vehicles", "Street Vehicles", "2EJpM1SDSYc",
					"https://img.youtube.com/vi/2EJpM1SDSYc/hqdefault.jpg", LocalDate.of(2022, 12, 22)));
			videoService.addVideo(new Video(
					"Feelings and Emotion Chant", ".", "zEk48QQSPo4",
					"https://img.youtube.com/vi/zEk48QQSPo4/hqdefault.jpg", LocalDate.of(2022, 12, 23)));
			videoService.addVideo(new Video(
					"Pablo - How are you?", ".", "rx4Po9DS5DA", "https://img.youtube.com/vi/rx4Po9DS5DA/hqdefault.jpg",
					LocalDate.of(2022, 12, 24)));
			videoService.addVideo(new Video(
					"Learn Shapes", ".", "E6qWBhEiP6g", "https://img.youtube.com/vi/E6qWBhEiP6g/hqdefault.jpg", LocalDate.of(2023, 01, 06)));
			videoService.addVideo(new Video(
					"Learn to Read", ".", "rj4DiUdi91Q", "https://img.youtube.com/vi/rj4DiUdi91Q/hqdefault.jpg", LocalDate.of(2023, 01, 8)));
			videoService.addVideo(new Video(
					"Learn Fruits", ".", "yBAXPA2ZSfM", "https://img.youtube.com/vi/yBAXPA2ZSfM/hqdefault.jpg", LocalDate.of(2023, 01, 9)));
			videoService.addVideo(new Video(
					"Wash your hands", ".", "bG6RMmbhCus", "https://img.youtube.com/vi/bG6RMmbhCus/hqdefault.jpg", LocalDate.of(2023, 01, 16)));
			videoService.addVideo(new Video(
					"Planets", ".", "gAEINCu_GD0", "https://img.youtube.com/vi/gAEINCu_GD0/hqdefault.jpg", LocalDate.of(2023, 02, 01)));
			videoService.addVideo(new Video(
					"Meet the Numbers", ".", "61OIyIox9mc", "https://img.youtube.com/vi/61OIyIox9mc/hqdefault.jpg", LocalDate.of(2023, 02, 04)));


			Role childRole = new Role();
			childRole.setRoleName("child");
			Role parentRole = new Role();
			parentRole.setRoleName("parent");
			Role adminRole = new Role();
			adminRole.setRoleName("admin");

			roleService.saveRole(childRole);
			roleService.saveRole(parentRole);

			User johnChild = new User("johnChild", "John Tan", "John123@", "John@gmail.com");
			johnChild.setActive(true);
			johnChild.setLastAccountAccess(LocalDate.now());
			johnChild.setRole(childRole);
			userService.saveUser(johnChild);

			User sallyChild = new User("sallyChild", "Sally Lee", "Sally123@", "Sally@gmail.com");
			sallyChild.setActive(true);
			sallyChild.setLastAccountAccess(LocalDate.now());
			sallyChild.setRole(childRole);
			userService.saveUser(sallyChild);

			videoWatchedService.saveVideoWatched(vid1, sallyChild);

			User johnAndSallyParent = new User("johnAndSallyParent", "Tom Tan", "Tomm123@", "Tom@gmail.com");
			johnAndSallyParent.setActive(true);
			johnAndSallyParent.setLastAccountAccess(LocalDate.now());
			johnAndSallyParent.setRole(parentRole);
			userService.saveUser(johnAndSallyParent);

			FamilyMember sally = new FamilyMember();
			sally.setUserName("sallyChild");
			sally.setUser(johnAndSallyParent);
			familyMemberService.saveFamilyMember(sally);

			FamilyMember john = new FamilyMember();
			john.setUserName("johnChild");
			john.setUser(johnAndSallyParent);
			familyMemberService.saveFamilyMember(john);

			User emilyChild = new User("emilyChild", "Emily Koh", "Emily123@", "Emily@gmail.com");
			emilyChild.setActive(true);
			emilyChild.setLastAccountAccess(LocalDate.now());
			emilyChild.setRole(childRole);
			userService.saveUser(emilyChild);

			User emilyParent = new User("emilyParent", "Richard Koh", "Richard123@", "Richard@gmail.com");
			emilyParent.setActive(true);
			emilyParent.setLastAccountAccess(LocalDate.now());
			emilyParent.setRole(parentRole);
			userService.saveUser(emilyParent);

			User taylorParent = new User("taylorParent", "Jiang", "Taylor123@", "galaxyts1007@gmail.com");
			taylorParent.setActive(true);
			taylorParent.setLastAccountAccess(LocalDate.now());
			taylorParent.setRole(parentRole);
			userService.saveUser(taylorParent);

			FamilyMember emily = new FamilyMember();
			emily.setUserName("emilyChild");
			emily.setUser(emilyParent);
			familyMemberService.saveFamilyMember(emily);

			User amyAdmin = new User("amyAdmin", "Amy Lee", "Amyy123@", "yl21770@gmail.com");
			amyAdmin.setActive(true);
			amyAdmin.setLastAccountAccess(LocalDate.now());
			amyAdmin.setRole(adminRole);
			roleService.saveRole(adminRole);
			userService.saveUser(amyAdmin);

			Quiz q1 = new Quiz();
			q1.setAttemptDate(LocalDate.now().minusMonths(2));
			q1.setScore(10);
			q1.setUser(johnChild);
			quizService.saveQuiz(q1);
			Quiz q2 = new Quiz();
			q2.setAttemptDate(LocalDate.now().minusMonths(2));
			q2.setScore(6);
			q2.setUser(johnChild);
			quizService.saveQuiz(q2);

			Survey surveyA = new Survey("Quality of Life- QOL Perception",
					"It includes items to weigh on emotional wellbeing, social inclusion and interpersonal relationships. Scores can range from 28 to 140, with higher scores indicating greater perceived QOL.",
					86);
			Survey surveyB = new Survey("Perception of the impact of the child's Autistic Spectrum Disorder Symptoms",
					"It lists the difficulties that children with ASD can experience and assess parents' perception of them.Scores can range from 20 to 100, with higher scores denoting fewer problems for parents regarding their child's ASD-related behaviours.",
					68);
			String[] surveyAQuestions = new String[] { "I am satisfied with my life.", "I don't feel stressed.",
					"I feel happy and content.", "I don't feel depressed or anxious.",
					"I feel good about myself as a person.",
					"I am satisfied with my close relationships.",
					"People are there for me when I need them.",
					"I am satisfied with my social life.",
					"I am satisfied with my family life.",
					"I am satisfied with my financial situation.",
					"I am satisfied with where I live.",
					"I have enough money to meet my needs.",
					"I am satisfied with my achievements.",
					"I am satisfied with my general health.",
					"I have a healthy lifestyle.",
					"I am satisfied with my leisure activities.",
					"I have no health problems that are stopping me from doing the things I want.",
					"I feel in control of my life.", "I set and achieve goals in my life.",
					"I can make a plan of action and follow it.", "I make my own decisions.",
					"I don't feel guilty.", "I am part of a community.",
					"I can get the support that I need from the community.",
					"I am able to get to where I need to.", "I feel safe in my everyday life.",
					"I feel respected in my everyday life.",
					"I am satisfied with the availability of health services." };
			surveyService.saveSurvey(surveyA);
			for (String s : surveyAQuestions) {
				SurveyQuestion q = new SurveyQuestion(s);
				q.setSurvey(surveyA);
				surveyQuestionService.saveSurveyQuestion(q);
			}

			String[] surveyBQuestions = new String[] {
					"My child's problem of Socialising with people is not much of a problem for me.",
					"My child's problem of Having friends is not much of a problem for me.",
					"My child's problem of Understanding others' feelings is not much of a problem for me.",
					"My child's problem of Holding a conversation is not much of a problem for me.",
					"My child's problem of Communicating needs is not much of a problem for me.",
					"My child's problem of Taking a literal meaning of comments is not much of a problem for me.",
					"My child's problem of Saying things that are socially embarassing is not much of a problem for me.",
					"My child's problem of Needing to stick to a routine is not much of a problem for me.",
					"My child's problem of Being overly interested in a particular topic is not much of a problem for me.",
					"My child's problem of Getting anxious in a specific situation or during changes is not much of a problem for me.",
					"My child's problem of Sensitivity to certain sensations is not much of a problem for me.",
					"My child's problem of Understanding the rules of social interaction is not much of a problem for me.",
					"My child's problem of Managing emotional responses is not much of a problem for me.",
					"My child's problem of Needing to do things a certain way is not much of a problem for me.",
					"My child's problem of Destructive behaviours including anger and aggression is not much of a problem for me.",
					"My child's problem of Showing inappropriate emotional reactions is not much of a problem for me.",
					"My child's problem of Unusual repetitive behaviours or body movements is not much of a problem for me.",
					"My child's problem of Engaging in reckless or tactless behaviours is not much of a problem for me.",
					"My child's problem of Doing daily living tasks independently is not much of a problem for me.",
					"My child's problem of Responding when approached socially is not much of a problem for me." };
			surveyService.saveSurvey(surveyB);
			for (String s : surveyBQuestions) {
				SurveyQuestion q = new SurveyQuestion(s);
				q.setSurvey(surveyB);
				surveyQuestionService.saveSurveyQuestion(q);
			}

			// adding dummy Feedbacks
			Feedback f1;
			Feedback f2;

			for (int x = 0; x < 25; x++) {
				f1 = new Feedback();
				f2 = new Feedback();
				f1.setSubject("test");
				f1.setDescription("testing");
				f1.setFeedbackDate(LocalDate.now());
				f1.setUser(johnAndSallyParent);
				f1.setRead(false);
				feedbackRepo.save(f1);

				f2.setSubject("alpha");
				f2.setDescription("testing alpha");
				f2.setFeedbackDate(LocalDate.now().minusDays(2));
				f2.setUser(emilyChild);
				f2.setRead(false);
				feedbackRepo.save(f2);
			}
		};
	}
}
