package sg.nus.iss.facialrecognition.model;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table
public class User {
    @Id
    @Column
    private String userName;

    @NotBlank(message = "The Full Name cannot be blank")
    @Column(columnDefinition = "nvarchar(150) not null")
    private String fullName;

    @NotBlank(message = "The Password cannot be blank")
    @Pattern(regexp = "^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$", message = "The password must be valid with at least one uppercase English letter, one lowercase English letter, at least one digit, at least one special character and minimum eight in length.")
    private String password;
    @Transient
    private String confirmPassword;

    @NotBlank(message = "The Email cannot be blank")
    @Email(message = "Email should be valid")
    @Size(max = 200)
    @Pattern(regexp = ".+@.+\\..+", message = "Email should be valid")
    private String email;

    public User(String userName, String fullName, String password, String email){
        this.userName = userName;
        this.fullName = fullName;
        this.password = password;
        this.email = email;
    }
    private String address;
    @ManyToOne
    private Role role;

    @Column
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate lastAccountAccess;

    @Column
    private boolean isActive;

    @OneToMany(mappedBy = "user")
    private List<FamilyMember> members;

    @OneToMany (mappedBy = "user")
    private List<Quiz> quizzes;

    @OneToMany (mappedBy = "user")
    private List<VideoWatched> videoWatched;

    @OneToMany(mappedBy = "user")
    private List<SurveyScore> surveyScores;

    private String token;
}
