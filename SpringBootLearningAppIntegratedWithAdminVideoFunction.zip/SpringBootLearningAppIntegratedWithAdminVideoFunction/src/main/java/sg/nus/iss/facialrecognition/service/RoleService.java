package sg.nus.iss.facialrecognition.service;

import sg.nus.iss.facialrecognition.model.Role;

public interface RoleService {
    Role saveRole(Role role);
    
}
